
$(document).ready(function(){
	//click delay + spinning cursor
    $("a").click(function(evt){
        $('body').css('cursor', 'wait');
        var image = document.createElement("img");
        image.src = chrome.extension.getURL("ClockGif.gif");
        $('div').append(image);
        $(image).css('position', 'absolute');
        $(image).css('z-index', '100');
        var href = $(this).attr('href');
        setTimeout(function() {
        	window.location = href;
        	$('body').css('cursor', 'default');
        }, 10000);

        //return false;
       });
    $("a").on( 'click', function (e) {
    e.preventDefault();
	});

}); // ready






